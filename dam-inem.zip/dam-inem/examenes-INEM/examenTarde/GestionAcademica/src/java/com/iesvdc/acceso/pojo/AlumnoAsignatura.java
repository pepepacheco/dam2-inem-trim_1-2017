/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.pojo;

/**
 *
 * @author matinal
 */
public class AlumnoAsignatura {
    private Asignatura asignatura;
    private Alumno alumno;
    private int faltas;
    
    public AlumnoAsignatura() {
    }

    public AlumnoAsignatura(Asignatura asignatura, Alumno alumno, int faltas) {
        this.asignatura = asignatura;
        this.alumno = alumno;
        this.faltas = faltas;
    }

    public Asignatura getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public int getFaltas() {
        return faltas;
    }

    public void setFaltas(int faltas) {
        this.faltas = faltas;
    }
    
    
}
