/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.pojo;

/**
 *
 * @author matinal
 */
public class ProfesorAsignatura {
    private Asignatura asignatura;
    private Profesor profesor;
    private int horasSemanales;
    
    public ProfesorAsignatura() {
    }

    public ProfesorAsignatura(Asignatura asignatura, Profesor profesor, int horasSemanales) {
        this.asignatura = asignatura;
        this.profesor = profesor;
        this.horasSemanales = horasSemanales;
    }

    public Asignatura getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public int getHorasSemanales() {
        return horasSemanales;
    }

    public void setHorasSemanales(int horasSemanales) {
        this.horasSemanales = horasSemanales;
    }
    
    
}
