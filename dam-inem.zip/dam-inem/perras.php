<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
<h1 align="center">"The Ultimate PhP Tragaperras"</h1>
<h2 align="center">Página de resultados</h2>
<p align="center">
<?php
$apuesta=$_GET['apuesta'];
$haber=$_GET['haber'];
echo "Tenías $haber €. ";
echo "Tu apuesta ha sido de $apuesta €.<br><br>";
//tirada
	$aleatorio=rand (1,5);
	$pos1=$aleatorio;
	$aleatorio=rand (1,5);
	$pos2=$aleatorio;
	$aleatorio=rand (1,5);
	$pos3=$aleatorio;
//echo $pos1.$pos2.$pos3; //
///////////////////////////////

//muestro las frutas
switch ($pos1)
	{
	case '1':
	?><img src="fruta/cereza.jpg" width="70px" height="70px"><?php
	break;
	
	case '2':
	?><img src="fruta/fresa.jpg" width="70px" height="70px"><?php
	break;
	
	case '3':
	?><img src="fruta/limon.jpg" width="70px" height="70px"><?php
	break;
	
	case '4':
	?><img src="fruta/piña.jpeg" width="70px" height="70px"><?php
	break;
	
	case '5':
	?><img src="fruta/platano.png" width="70px" height="70px"><?php
	break;
	
	default:
	echo "sintax error";
	
	}

switch ($pos2)
	{
	case '1':
	?><img src="fruta/cereza.jpg" width="70px" height="70px"><?php
	break;
	
	case '2':
	?><img src="fruta/fresa.jpg" width="70px" height="70px"><?php
	break;
	
	case '3':
	?><img src="fruta/limon.jpg" width="70px" height="70px"><?php
	break;
	
	case '4':
	?><img src="fruta/piña.jpeg" width="70px" height="70px"><?php
	break;
	
	case '5':
	?><img src="fruta/platano.png" width="70px" height="70px"><?php
	break;
	
	default:
	echo "sintax error";
	
	}
switch ($pos3)
	{
	case '1':
	?><img src="fruta/cereza.jpg" width="70px" height="70px"><?php
	break;
	
	case '2':
	?><img src="fruta/fresa.jpg" width="70px" height="70px"><?php
	break;
	
	case '3':
	?><img src="fruta/limon.jpg" width="70px" height="70px"><?php
	break;
	
	case '4':
	?><img src="fruta/piña.jpeg" width="70px" height="70px"><?php
	break;
	
	case '5':
	?><img src="fruta/platano.png" width="70px" height="70px"><?php
	break;
	
	default:
	echo "sintax error";
	
	}
echo "<br>";
/////////////////////////////////////////////////

//premios
$cereza=0;
$fresa=0;
$limon=0;
$pinya=0;
$platano=0;
if ($pos1==1){$cereza++;}
if ($pos2==1){$cereza++;}
if ($pos3==1){$cereza++;}
if ($pos1==2){$fresa++;}
if ($pos2==2){$fresa++;}
if ($pos3==2){$fresa++;}
if ($pos1==3){$limon++;}
if ($pos2==3){$limon++;}
if ($pos3==3){$limon++;}
if ($pos1==4){$pinya++;}
if ($pos2==4){$pinya++;}
if ($pos3==4){$pinya++;}
if ($pos1==5){$platano++;}
if ($pos2==5){$platano++;}
if ($pos3==5){$platano++;}

//echo $cereza.$fresa.$limon.$pinya.$platano.'<br>';

if ($cereza==1 && ($fresa==2 || $limon==2 || $pinya==2 || $platano==2)){$premio=$apuesta*3;}
elseif ($cereza==1){$premio=$apuesta;}
elseif ($cereza==2){$premio=$apuesta*4;}
elseif ($cereza==3){$premio=$apuesta*10;}
elseif ($fresa==2 || $limon==2 || $pinya==2 || $platano==2){$premio=$apuesta*2;}
elseif ($fresa==3 || $limon==3 || $pinya==3 || $platano==3){$premio=$apuesta*5;}
else {$premio=0;}

if ($premio==0 && $haber==0)
{
	echo '</p><h1 align="center">Has perdido tu dinero!</h1>';
	echo '<h1 align="center">Inserta monedas para seguir jugando</h1><p align="center">';
}
elseif ($premio==0 && $haber!=0)
{
 	echo '</p><h1 align="center">No has ganado</h1>';
	//echo '<h1 align="center">Tienes todavía '.$haber.'</h1><p align="center">';
		$haber=$haber-$apuesta;
	?>
<p align="center"><a href="perras.php?apuesta=<?=$apuesta?>&haber=<?=$haber?>"><input type="button" value="SIGUE JUGANDO"></a><br>
    <?php

}
else
{
	echo '<h1 align="center">Tu Premio es de '.$premio.' €</h1>';
	$haber=$haber+$premio;
		$haber=$haber-$apuesta;
	?>
<p align="center"><a href="perras.php?apuesta=<?=$apuesta?>&haber=<?=$haber?>"><input type="button" value="SIGUE JUGANDO"></a><br>
    <?php
}

echo "Ahora tienes $haber €.<br>";

?>
<a href="traga.html"><input type="button" value="inserta moneda"></a>
</p>
</body>
</html>